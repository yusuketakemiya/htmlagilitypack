**Html Agility Pack Examples**

For example, here is how you would fix all hrefs in an HTML file: 
{{
 HtmlDocument doc = new HtmlDocument();
 doc.Load("file.htm");
 foreach(HtmlNode link in doc.DocumentElement.SelectNodes("//a[@href"](@href_))
 {
    HtmlAttribute att = link["href"](_href_);
    att.Value = FixLink(att);
 }
 doc.Save("file.htm");
}}